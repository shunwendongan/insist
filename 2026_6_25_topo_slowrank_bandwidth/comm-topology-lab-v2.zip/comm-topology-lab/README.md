# comm-topology-lab

一个用于演示 **NCCL 慢 rank / 可疑链路 / GPU 拓扑诊断** 的最小工程。

这个 demo 会解析：

```text
data/nccl_trace.log
data/topology.json
```

并自动生成：

```text
reports/slow_rank_report.md
reports/analysis_flow.md
reports/images/topology_slow_link.png
reports/images/rank_latency_bar.png
reports/images/link_health_heatmap.png
```

## 在 Colab 中运行

把 `comm-topology-lab-v2.zip` 上传到 Colab 后，运行这一整块：

```python
!rm -rf comm-topology-lab
!unzip -o comm-topology-lab-v2.zip
%cd comm-topology-lab
!python src/find_slow_rank.py

from IPython.display import Markdown, Image, display

display(Markdown(open("reports/analysis_flow.md").read()))
display(Markdown(open("reports/slow_rank_report.md").read()))
display(Image("reports/images/topology_slow_link.png"))
display(Image("reports/images/rank_latency_bar.png"))
display(Image("reports/images/link_health_heatmap.png"))
```

## 在本地运行

```bash
unzip -o comm-topology-lab-v2.zip
cd comm-topology-lab
python3 src/find_slow_rank.py
cat reports/slow_rank_report.md
```

## 输出解读

核心结论会类似：

```text
slow_rank=3
suspicious_links=PHB0,NVL2,NVL3
```

其中：

- `slow_rank=3` 表示 rank 3 是最可能的慢 rank。
- `PHB0` 是首要可疑链路。
- 报告会进一步说明为什么怀疑 PHB0，以及下一步应该运行哪些命令验证。

## 项目结构

```text
comm-topology-lab/
├── README.md
├── data/
│   ├── nccl_trace.log
│   └── topology.json
├── src/
│   └── find_slow_rank.py
└── reports/
    ├── analysis_flow.md
    ├── slow_rank_report.md
    └── images/
        ├── topology_slow_link.png
        ├── rank_latency_bar.png
        └── link_health_heatmap.png
```

## 这个 demo 展示的诊断流程

```text
NCCL trace
    ↓
解析 rank / peer / latency / link
    ↓
计算全局 median latency
    ↓
识别 slow events
    ↓
按 rank 聚合，找慢 rank
    ↓
按 link 聚合，找可疑链路
    ↓
结合 topology JSON 判断是否跨 NUMA / PCIe host bridge / NVLink
    ↓
生成 Markdown 报告和三张图
    ↓
给出下一步验证命令
```
