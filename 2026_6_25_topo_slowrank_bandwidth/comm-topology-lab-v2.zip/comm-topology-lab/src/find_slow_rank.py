#!/usr/bin/env python3
"""Analyze a simplified NCCL trace plus topology JSON.

This demo answers three practical debugging questions:
1. Which rank is slow?
2. Which link is suspicious?
3. What should we validate next?

It also generates three visual artifacts:
- reports/images/topology_slow_link.png
- reports/images/rank_latency_bar.png
- reports/images/link_health_heatmap.png
"""
from __future__ import annotations

import argparse
import json
import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from statistics import median
from typing import Dict, Iterable, List, Tuple

import matplotlib.pyplot as plt

LINE_RE = re.compile(
    r"^(?P<ts>\d+(?:\.\d+)?)\s+"
    r"(?P<op>\w+)\s+"
    r"(?P<comm>\w+)\s+"
    r"rank=(?P<rank>\d+)\s+"
    r"peer=(?P<peer>\d+)\s+"
    r"bytes=(?P<bytes>\d+)\s+"
    r"duration_ms=(?P<duration>\d+(?:\.\d+)?)\s+"
    r"link=(?P<link>\S+)"
)


@dataclass(frozen=True)
class Event:
    ts_ms: float
    op: str
    comm: str
    rank: int
    peer: int
    bytes: int
    duration_ms: float
    link: str

    @property
    def gbps(self) -> float:
        # bytes -> bits, ms -> seconds, / 1e9
        return (self.bytes * 8) / (self.duration_ms / 1000.0) / 1e9


def parse_trace(path: Path) -> List[Event]:
    events: List[Event] = []
    for lineno, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        m = LINE_RE.match(line)
        if not m:
            raise ValueError(f"Cannot parse {path}:{lineno}: {line}")
        d = m.groupdict()
        events.append(
            Event(
                ts_ms=float(d["ts"]),
                op=d["op"],
                comm=d["comm"],
                rank=int(d["rank"]),
                peer=int(d["peer"]),
                bytes=int(d["bytes"]),
                duration_ms=float(d["duration"]),
                link=d["link"],
            )
        )
    return events


def load_topology(path: Path) -> Tuple[dict, Dict[str, dict], Dict[int, dict]]:
    topo = json.loads(path.read_text(encoding="utf-8"))
    link_by_name = {link["name"]: link for link in topo.get("links", [])}
    gpu_by_rank = {gpu["rank"]: gpu for gpu in topo.get("gpus", [])}
    return topo, link_by_name, gpu_by_rank


def pct_delta(value: float, baseline: float) -> float:
    if baseline == 0:
        return 0.0
    return (value - baseline) / baseline * 100.0


def summarize(events: Iterable[Event], link_by_name: Dict[str, dict], slow_factor: float) -> dict:
    events = list(events)
    global_median = median(e.duration_ms for e in events)
    slow_threshold = global_median * slow_factor

    by_rank: Dict[int, List[Event]] = defaultdict(list)
    by_link: Dict[str, List[Event]] = defaultdict(list)
    for e in events:
        by_rank[e.rank].append(e)
        by_link[e.link].append(e)

    rank_rows = []
    for rank, evs in sorted(by_rank.items()):
        med = median(e.duration_ms for e in evs)
        max_ms = max(e.duration_ms for e in evs)
        min_gbps = min(e.gbps for e in evs)
        slow_events = [e for e in evs if e.duration_ms >= slow_threshold]
        rank_rows.append(
            {
                "rank": rank,
                "events": len(evs),
                "median_ms": med,
                "max_ms": max_ms,
                "min_gbps": min_gbps,
                "slow_events": len(slow_events),
                "score": pct_delta(med, global_median) + len(slow_events) * 50,
                "links": Counter(e.link for e in evs).most_common(),
            }
        )

    link_rows = []
    for name, evs in sorted(by_link.items()):
        med = median(e.duration_ms for e in evs)
        max_ms = max(e.duration_ms for e in evs)
        avg_gbps = sum(e.gbps for e in evs) / len(evs)
        topo = link_by_name.get(name, {})
        expected = topo.get("expected_gbps")
        ratio = (avg_gbps / expected) if expected else None
        slow_count = sum(1 for e in evs if e.duration_ms >= slow_threshold)
        health = topo.get("health", "unknown")
        suspicious = slow_count > 0 or health == "suspect" or (ratio is not None and ratio < 0.55)
        link_rows.append(
            {
                "name": name,
                "type": topo.get("type", "unknown"),
                "pair": (topo.get("src"), topo.get("dst")),
                "health": health,
                "events": len(evs),
                "median_ms": med,
                "max_ms": max_ms,
                "avg_gbps": avg_gbps,
                "expected_gbps": expected,
                "throughput_ratio": ratio,
                "slow_events": slow_count,
                "suspicious": suspicious,
                "note": topo.get("note", ""),
            }
        )

    slow_ranks = sorted(rank_rows, key=lambda r: (r["score"], r["median_ms"]), reverse=True)
    suspicious_links = sorted(
        [l for l in link_rows if l["suspicious"]],
        key=lambda l: (l["slow_events"], l["max_ms"]),
        reverse=True,
    )
    return {
        "global_median_ms": global_median,
        "slow_threshold_ms": slow_threshold,
        "rank_rows": rank_rows,
        "link_rows": link_rows,
        "slow_ranks": slow_ranks,
        "suspicious_links": suspicious_links,
    }


def md_table(headers: List[str], rows: List[List[object]]) -> str:
    out = ["| " + " | ".join(headers) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"]
    for row in rows:
        out.append("| " + " | ".join(str(x) for x in row) + " |")
    return "\n".join(out)


def render_report(summary: dict, gpu_by_rank: Dict[int, dict], image_dir: Path) -> str:
    slow_ranks = summary["slow_ranks"]
    suspicious_links = summary["suspicious_links"]
    top_rank = slow_ranks[0]
    top_link = suspicious_links[0]["name"] if suspicious_links else "none"

    rank_rows = []
    for r in slow_ranks:
        gpu = gpu_by_rank.get(r["rank"], {})
        rank_rows.append([
            r["rank"],
            gpu.get("gpu", "?"),
            gpu.get("numa", "?"),
            f'{r["median_ms"]:.1f}',
            f'{r["max_ms"]:.1f}',
            f'{r["min_gbps"]:.1f}',
            r["slow_events"],
            ", ".join(f"{k}x{v}" for k, v in r["links"]),
        ])

    link_rows = []
    for l in suspicious_links:
        pair = f'{l["pair"][0]}<->{l["pair"][1]}'
        ratio = "n/a" if l["throughput_ratio"] is None else f'{l["throughput_ratio"]:.2f}x'
        link_rows.append([
            l["name"], pair, l["type"], l["health"], f'{l["median_ms"]:.1f}', f'{l["max_ms"]:.1f}',
            f'{l["avg_gbps"]:.1f}', l["expected_gbps"], ratio, l["slow_events"], l["note"] or "-"
        ])

    commands = [
        "nvidia-smi topo -m",
        "nvidia-smi nvlink --status",
        "nvidia-smi dmon -s pucvmet -d 1",
        "dcgmi diag -r 3",
        "dcgmi dmon -e 1002,1003,1004,1005",
        "NCCL_DEBUG=INFO NCCL_DEBUG_SUBSYS=INIT,GRAPH,COLL ./your_nccl_test",
        "NCCL_TOPO_DUMP_FILE=/tmp/nccl_topo.xml NCCL_DEBUG=INFO ./your_nccl_test",
        "numactl --hardware && lspci -tv",
    ]

    return f"""# Slow Rank Report

## Verdict

Most likely slow rank: **rank {top_rank['rank']}**. It repeatedly touches the slow path and has max latency **{top_rank['max_ms']:.1f} ms** versus global median **{summary['global_median_ms']:.1f} ms**.

Primary suspect link: **{top_link}**. In this sample, slow events cluster on the cross-socket / host-bridge path, so the first hypothesis is PCIe/NUMA topology or link health rather than a pure NCCL algorithm issue.

## Visual artifacts

### GPU topology with highlighted slow link

![GPU topology](images/topology_slow_link.png)

### Rank latency bar chart

![Rank latency](images/rank_latency_bar.png)

### Link health heatmap

![Link health heatmap](images/link_health_heatmap.png)

## Rank summary

{md_table(['Rank','GPU','NUMA','Median ms','Max ms','Min Gb/s','Slow events','Links seen'], rank_rows)}

## Suspicious links

{md_table(['Link','Pair','Type','Topo health','Median ms','Max ms','Avg Gb/s','Expected Gb/s','Ratio','Slow events','Note'], link_rows)}

## Next validation commands

```bash
{chr(10).join(commands)}
```

## Suggested triage order

1. Confirm whether NCCL chose a ring/tree edge across the same suspicious path.
2. Compare `nvidia-smi topo -m` with the JSON topology and check whether rank mapping is suboptimal.
3. Watch PCIe replay/error counters while re-running the collective benchmark.
4. Try a rank remap that avoids the suspicious edge, then compare p50/p95 latency.
5. If only this edge is slow under load, isolate hardware: cable/riser/switch/host bridge/NUMA placement.
"""


def render_analysis_flow_md() -> str:
    return """# NCCL Slow Rank Analysis Flow

这个文件描述 `comm-topology-lab` 的完整分析流程。目标是把一份简化 NCCL trace 和一份 GPU 拓扑 JSON 合起来，自动输出：

1. 慢 rank 是谁。
2. 哪条链路最可疑。
3. 为什么怀疑它。
4. 下一步应该用哪些命令验证。
5. 生成可视化图：GPU 拓扑图、rank 延迟柱状图、链路健康热力图。

---

## 1. 输入数据

项目使用两个输入文件：

```text
 data/nccl_trace.log
 data/topology.json
```

### 1.1 `nccl_trace.log`

每一行代表一次简化后的 NCCL 通信事件：

```text
ts_ms op comm rank peer bytes duration_ms link
```

字段含义：

| 字段 | 含义 |
| --- | --- |
| `ts_ms` | 事件时间戳，单位 ms |
| `op` | collective 类型，例如 `all_reduce`、`all_gather`、`reduce_scatter` |
| `comm` | NCCL 使用的通信结构，例如 `ring` 或 `tree` |
| `rank` | 当前 rank |
| `peer` | 当前 rank 通信的对端 rank |
| `bytes` | 本次通信数据量 |
| `duration_ms` | 本次通信耗时，越大越慢 |
| `link` | 本次通信经过的逻辑链路，例如 `NVL0`、`PHB0`、`PIX0` |

### 1.2 `topology.json`

拓扑文件描述：

- rank 到 GPU 的映射。
- GPU 所在 NUMA 节点。
- GPU 之间的链路类型。
- 链路理论带宽。
- 拓扑健康状态。

示例链路：

```json
{
  "src": 3,
  "dst": 4,
  "name": "PHB0",
  "type": "PCIe host bridge",
  "expected_gbps": 32,
  "health": "suspect"
}
```

这表示 rank 3 和 rank 4 之间经过一条 PCIe host bridge 路径，并且拓扑层面已经标记为可疑。

---

## 2. 解析 NCCL trace

脚本首先逐行读取 `data/nccl_trace.log`，用正则表达式提取：

```text
rank, peer, bytes, duration_ms, link
```

然后把每一条通信记录转换成 `Event` 对象。

每个 `Event` 会额外计算吞吐：

```text
gbps = bytes * 8 / duration_seconds / 1e9
```

这个值用于判断某条链路是否明显低于预期带宽。

---

## 3. 计算全局基线

脚本会先计算所有通信事件的全局中位数延迟：

```text
global_median_ms = median(all duration_ms)
```

在这个 demo 中，全局中位数大约是：

```text
13.1 ms
```

然后定义慢事件阈值：

```text
slow_threshold = global_median_ms * slow_factor
```

默认：

```text
slow_factor = 1.8
```

所以只要某次通信耗时明显高于全局中位数，就会被标记为 slow event。

---

## 4. Rank 维度分析

脚本会按 rank 分组，统计每个 rank 的：

| 指标 | 含义 |
| --- | --- |
| `median_ms` | 该 rank 的中位数延迟，反映整体是否偏慢 |
| `max_ms` | 该 rank 的最大延迟，反映最坏情况 |
| `min_gbps` | 该 rank 的最低吞吐，反映是否出现带宽塌陷 |
| `slow_events` | 该 rank 出现慢事件的次数 |
| `links` | 该 rank 经过过哪些链路 |

判断慢 rank 时，不只看单次最大值，而是综合：

```text
rank_score = median 相对全局中位数的涨幅 + slow_events 惩罚项
```

这样可以避免一个 rank 只因为偶发尖刺就被误判。

在当前样例中：

```text
rank 3 多次经过慢路径，并且 median_ms 明显高于其他 rank
```

所以报告给出：

```text
Most likely slow rank: rank 3
```

---

## 5. Link 维度分析

脚本还会按 link 分组，统计每条链路的：

| 指标 | 含义 |
| --- | --- |
| `median_ms` | 经过该链路时的中位延迟 |
| `max_ms` | 经过该链路时的最大延迟 |
| `avg_gbps` | 平均吞吐 |
| `expected_gbps` | topology JSON 中记录的理论带宽 |
| `throughput_ratio` | 实测吞吐 / 理论带宽 |
| `slow_events` | 该链路关联的慢事件次数 |
| `health` | topology JSON 中的健康状态 |

一条链路会被认为可疑，如果满足任意条件：

```text
slow_events > 0
或 health == suspect
或 throughput_ratio < 0.55
```

在当前 demo 中，最可疑的是：

```text
PHB0
```

原因是：

1. `PHB0` 关联了多个 slow event。
2. `PHB0` 是跨 GPU3 和 GPU4 的路径。
3. 该路径类型是 `PCIe host bridge`。
4. topology JSON 已经把它标记为 `suspect`。
5. note 中提示：`cross-socket path; prior DCGM saw replay counter bumps`。

因此初步判断不是 NCCL 算法本身的问题，而更像是：

```text
PCIe / NUMA / host bridge / 拓扑映射 / 硬件链路健康问题
```

---

## 6. 可视化输出

脚本会自动生成三张图：

```text
reports/images/topology_slow_link.png
reports/images/rank_latency_bar.png
reports/images/link_health_heatmap.png
```

### 6.1 GPU 拓扑图

拓扑图展示 GPU 之间的连接关系：

- 每个节点代表一个 rank/GPU。
- 边代表 topology JSON 中的链路。
- 慢链路或可疑链路会被高亮。
- `PHB0` 会用红色高亮，帮助快速定位异常路径。

这张图用于回答：

```text
慢 rank 在拓扑上连接到了哪里？
慢链路是否跨 NUMA / 跨 socket？
```

### 6.2 Rank 延迟柱状图

柱状图展示每个 rank 的 median latency 和 max latency。

这张图用于回答：

```text
哪个 rank 的延迟整体更高？
哪个 rank 出现了最大尖刺？
```

在当前 demo 中，rank 3 会明显高于其他 rank。

### 6.3 Link 健康热力图

热力图把每条链路的风险拆成几个维度：

| 维度 | 含义 |
| --- | --- |
| `latency_ratio` | 链路中位延迟相对全局中位数的比例 |
| `slow_events` | 慢事件数量归一化 |
| `throughput_deficit` | 实测吞吐低于预期的程度 |
| `topology_flag` | topology 是否标记 suspect |

这张图用于回答：

```text
哪条链路的综合风险最高？
是延迟问题、吞吐问题，还是拓扑健康标记问题？
```

---

## 7. 报告生成

脚本最终生成：

```text
reports/slow_rank_report.md
```

报告包含：

1. 结论。
2. 三张可视化图。
3. Rank summary 表格。
4. Suspicious links 表格。
5. 下一步验证命令。
6. 建议排查顺序。

---

## 8. 下一步验证命令含义

### 查看 GPU 拓扑

```bash
nvidia-smi topo -m
```

用于验证真实机器上的 GPU 拓扑关系，例如：

- GPU 是否经过 NVLink。
- GPU 是否经过同一个 PCIe switch。
- GPU 是否跨 CPU socket。
- GPU 和 NIC 是否靠近。

### 查看 NVLink 状态

```bash
nvidia-smi nvlink --status
```

用于确认 NVLink 是否正常，例如是否出现 link down。

### 监控 GPU 运行状态

```bash
nvidia-smi dmon -s pucvmet -d 1
```

用于观察 GPU 利用率、功耗、温度、显存、PCIe 传输等指标。

### 运行 DCGM 诊断

```bash
dcgmi diag -r 3
```

用于检查 GPU 健康状况。

### 监控 DCGM 指标

```bash
dcgmi dmon -e 1002,1003,1004,1005
```

用于观察 PCIe / NVLink / replay counter 等可能影响通信性能的指标。

### 打开 NCCL Debug

```bash
NCCL_DEBUG=INFO NCCL_DEBUG_SUBSYS=INIT,GRAPH,COLL ./your_nccl_test
```

用于确认 NCCL 实际选择了什么 ring/tree 图，以及慢路径是否真的在 NCCL graph 里。

### Dump NCCL Topology

```bash
NCCL_TOPO_DUMP_FILE=/tmp/nccl_topo.xml NCCL_DEBUG=INFO ./your_nccl_test
```

用于导出 NCCL 看到的拓扑，和 `nvidia-smi topo -m`、`topology.json` 进行对比。

### 检查 NUMA 和 PCIe 树

```bash
numactl --hardware && lspci -tv
```

用于确认 GPU、CPU socket、PCIe switch、root complex 的真实挂载关系。

---

## 9. 推荐排查顺序

真实排障时建议按这个顺序：

1. 先确认慢 rank：看 rank latency 和 slow events。
2. 再确认慢链路：看 link summary 和 heatmap。
3. 看 NCCL 是否真的选择了这条链路。
4. 对比 `nvidia-smi topo -m` 和 NCCL topo dump。
5. 监控 PCIe / NVLink / DCGM counters。
6. 尝试 rank remapping，避开可疑链路。
7. 如果 remap 后性能恢复，说明拓扑路径强相关。
8. 如果始终只有同一条物理路径慢，继续排查硬件：线缆、riser、switch、host bridge、NUMA placement。

---

## 10. 当前 demo 的结论

当前样例的结论是：

```text
慢 rank: rank 3
可疑链路: PHB0
初步原因: 跨 socket / PCIe host bridge 路径异常，可能伴随 PCIe replay counter 增加
```

更像是：

```text
拓扑/链路/硬件健康问题
```

而不是：

```text
单纯 NCCL 算法问题
```
"""


def stable_positions(ranks: List[int]) -> Dict[int, Tuple[float, float]]:
    """Place NUMA-0 GPUs on the left and NUMA-1 GPUs on the right."""
    # Fixed positions make the generated topology graph deterministic and easy to compare in GitHub.
    return {
        0: (-2.2, 1.2),
        1: (-0.8, 1.2),
        2: (-2.2, -0.2),
        3: (-0.8, -0.2),
        4: (0.8, -0.2),
        5: (2.2, -0.2),
        6: (0.8, 1.2),
        7: (2.2, 1.2),
    } | {r: (math.cos(i), math.sin(i)) for i, r in enumerate(ranks) if r not in range(8)}


def generate_topology_graph(topo: dict, summary: dict, gpu_by_rank: Dict[int, dict], out: Path) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    ranks = [g["rank"] for g in topo.get("gpus", [])]
    pos = stable_positions(ranks)

    suspicious_names = {l["name"] for l in summary["suspicious_links"]}
    primary_name = summary["suspicious_links"][0]["name"] if summary["suspicious_links"] else None

    fig, ax = plt.subplots(figsize=(11, 6))
    ax.set_title("GPU topology with highlighted suspicious link", fontsize=14, pad=16)

    # Draw NUMA regions.
    ax.axvspan(-2.8, 0.0, alpha=0.06, color="tab:blue")
    ax.axvspan(0.0, 2.8, alpha=0.06, color="tab:green")
    ax.text(-1.4, 2.0, "NUMA 0", ha="center", fontsize=11, weight="bold")
    ax.text(1.4, 2.0, "NUMA 1", ha="center", fontsize=11, weight="bold")

    # Draw edges first so nodes sit on top.
    for link in topo.get("links", []):
        src, dst, name = link["src"], link["dst"], link["name"]
        x1, y1 = pos[src]
        x2, y2 = pos[dst]
        if name == primary_name:
            color, width, alpha, z = "red", 4.2, 0.95, 4
        elif name in suspicious_names:
            color, width, alpha, z = "orange", 3.0, 0.85, 3
        elif link.get("type") == "NVLink":
            color, width, alpha, z = "#4c78a8", 2.0, 0.65, 2
        else:
            color, width, alpha, z = "#999999", 1.4, 0.55, 1
        ax.plot([x1, x2], [y1, y2], color=color, linewidth=width, alpha=alpha, zorder=z)
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2
        ax.text(mx, my + 0.08, name, ha="center", va="center", fontsize=9,
                bbox=dict(boxstyle="round,pad=0.18", fc="white", ec="none", alpha=0.8))

    top_rank = summary["slow_ranks"][0]["rank"]
    for rank in ranks:
        x, y = pos[rank]
        gpu = gpu_by_rank.get(rank, {})
        is_slow = rank == top_rank
        face = "#ffdddd" if is_slow else "white"
        edge = "red" if is_slow else "#333333"
        width = 3.0 if is_slow else 1.5
        ax.scatter([x], [y], s=1650, facecolor=face, edgecolor=edge, linewidth=width, zorder=10)
        label = f"rank {rank}\n{gpu.get('gpu', 'GPU?')}"
        ax.text(x, y, label, ha="center", va="center", fontsize=10, zorder=11)

    ax.text(
        0,
        -1.15,
        f"Primary suspect: {primary_name or 'none'} | Slow rank: rank {top_rank}",
        ha="center",
        fontsize=11,
        bbox=dict(boxstyle="round,pad=0.4", fc="#fff2f2", ec="red", alpha=0.9),
    )
    ax.set_xlim(-3.0, 3.0)
    ax.set_ylim(-1.55, 2.25)
    ax.axis("off")
    fig.tight_layout()
    fig.savefig(out, dpi=160, bbox_inches="tight")
    plt.close(fig)


def generate_rank_latency_bar(summary: dict, out: Path) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    rows = sorted(summary["rank_rows"], key=lambda r: r["rank"])
    ranks = [f"rank {r['rank']}" for r in rows]
    medians = [r["median_ms"] for r in rows]
    maxes = [r["max_ms"] for r in rows]
    top_rank = summary["slow_ranks"][0]["rank"]
    colors = ["red" if r["rank"] == top_rank else "#8c8c8c" for r in rows]

    fig, ax = plt.subplots(figsize=(10, 5.5))
    bars = ax.bar(ranks, medians, color=colors, alpha=0.85, label="median latency")
    ax.scatter(ranks, maxes, color="black", marker="D", s=44, label="max latency")
    ax.axhline(summary["global_median_ms"], color="#3366aa", linestyle="--", linewidth=1.5, label="global median")
    ax.axhline(summary["slow_threshold_ms"], color="red", linestyle=":", linewidth=1.8, label="slow threshold")
    ax.set_title("Rank latency: median bars and max-latency markers", fontsize=14, pad=14)
    ax.set_ylabel("Latency (ms)")
    ax.set_xlabel("Rank")
    ax.legend(loc="upper left")
    ax.grid(axis="y", alpha=0.25)
    for bar, val in zip(bars, medians):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.45, f"{val:.1f}",
                ha="center", va="bottom", fontsize=9)
    fig.tight_layout()
    fig.savefig(out, dpi=160, bbox_inches="tight")
    plt.close(fig)


def generate_link_health_heatmap(summary: dict, out: Path) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    rows = sorted(summary["link_rows"], key=lambda l: (l["suspicious"], l["slow_events"], l["max_ms"]), reverse=True)
    names = [l["name"] for l in rows]

    max_slow = max([l["slow_events"] for l in rows] + [1])
    max_latency_ratio = max([l["median_ms"] / summary["global_median_ms"] for l in rows] + [1])

    matrix = []
    for l in rows:
        latency_ratio = l["median_ms"] / summary["global_median_ms"]
        latency_risk = min(latency_ratio / max_latency_ratio, 1.0)
        slow_event_risk = l["slow_events"] / max_slow
        if l["throughput_ratio"] is None:
            throughput_deficit = 0.0
        else:
            throughput_deficit = max(0.0, 1.0 - min(l["throughput_ratio"], 1.0))
        topology_flag = 1.0 if l["health"] == "suspect" else 0.0
        matrix.append([latency_risk, slow_event_risk, throughput_deficit, topology_flag])

    cols = ["latency\nratio", "slow\nevents", "throughput\ndeficit", "topology\nflag"]
    fig, ax = plt.subplots(figsize=(9, max(4.5, len(rows) * 0.45)))
    im = ax.imshow(matrix, aspect="auto", cmap="Reds", vmin=0, vmax=1)
    ax.set_title("Link health risk heatmap", fontsize=14, pad=14)
    ax.set_xticks(range(len(cols)))
    ax.set_xticklabels(cols)
    ax.set_yticks(range(len(names)))
    ax.set_yticklabels(names)
    for i, row in enumerate(matrix):
        for j, value in enumerate(row):
            ax.text(j, i, f"{value:.2f}", ha="center", va="center", fontsize=8)
    cbar = fig.colorbar(im, ax=ax, fraction=0.035, pad=0.04)
    cbar.set_label("Risk score, normalized 0-1")
    fig.tight_layout()
    fig.savefig(out, dpi=160, bbox_inches="tight")
    plt.close(fig)


def generate_artifacts(topo: dict, summary: dict, gpu_by_rank: Dict[int, dict], report_dir: Path) -> None:
    image_dir = report_dir / "images"
    generate_topology_graph(topo, summary, gpu_by_rank, image_dir / "topology_slow_link.png")
    generate_rank_latency_bar(summary, image_dir / "rank_latency_bar.png")
    generate_link_health_heatmap(summary, image_dir / "link_health_heatmap.png")
    (report_dir / "analysis_flow.md").write_text(render_analysis_flow_md(), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Find slow ranks from simplified NCCL trace and topology JSON")
    parser.add_argument("--trace", default="data/nccl_trace.log", type=Path)
    parser.add_argument("--topology", default="data/topology.json", type=Path)
    parser.add_argument("--out", default="reports/slow_rank_report.md", type=Path)
    parser.add_argument("--slow-factor", default=1.8, type=float, help="duration >= median*factor is marked slow")
    parser.add_argument("--no-plots", action="store_true", help="skip PNG visualization generation")
    args = parser.parse_args()

    events = parse_trace(args.trace)
    topo, link_by_name, gpu_by_rank = load_topology(args.topology)
    summary = summarize(events, link_by_name, args.slow_factor)

    report_dir = args.out.parent
    report_dir.mkdir(parents=True, exist_ok=True)
    if not args.no_plots:
        generate_artifacts(topo, summary, gpu_by_rank, report_dir)

    report = render_report(summary, gpu_by_rank, report_dir / "images")
    args.out.write_text(report, encoding="utf-8")

    top = summary["slow_ranks"][0]
    print(f"slow_rank={top['rank']} max_ms={top['max_ms']:.1f} report={args.out}")
    if summary["suspicious_links"]:
        print("suspicious_links=" + ",".join(l["name"] for l in summary["suspicious_links"]))
    if not args.no_plots:
        print("artifacts=reports/analysis_flow.md,reports/images/topology_slow_link.png,reports/images/rank_latency_bar.png,reports/images/link_health_heatmap.png")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
