#!/usr/bin/env python3
"""Analyze a simplified NCCL trace plus topology JSON.

Outputs:
- slow ranks by latency and normalized throughput
- suspicious links correlated with slow events
- next-step verification commands
"""
from __future__ import annotations

import argparse
import json
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from statistics import median
from typing import Dict, Iterable, List, Tuple

LINE_RE = re.compile(
    r"^(?P<ts>\d+(?:\.\d+)?)\s+"
    r"(?P<op>\w+)\s+"
    r"(?P<comm>\w+)\s+"
    r"rank=(?P<rank>\d+)\s+"
    r"peer=(?P<peer>\d+)\s+"
    r"bytes=(?P<bytes>\d+)\s+"
    r"duration_ms=(?P<duration>\d+(?:\.\d+)?)\s+"
    r"link=(?P<link>\S+)"
)


@dataclass(frozen=True)
class Event:
    ts_ms: float
    op: str
    comm: str
    rank: int
    peer: int
    bytes: int
    duration_ms: float
    link: str

    @property
    def gbps(self) -> float:
        # bytes -> bits, ms -> seconds, / 1e9
        return (self.bytes * 8) / (self.duration_ms / 1000.0) / 1e9


def parse_trace(path: Path) -> List[Event]:
    events: List[Event] = []
    for lineno, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        m = LINE_RE.match(line)
        if not m:
            raise ValueError(f"Cannot parse {path}:{lineno}: {line}")
        d = m.groupdict()
        events.append(
            Event(
                ts_ms=float(d["ts"]),
                op=d["op"],
                comm=d["comm"],
                rank=int(d["rank"]),
                peer=int(d["peer"]),
                bytes=int(d["bytes"]),
                duration_ms=float(d["duration"]),
                link=d["link"],
            )
        )
    return events


def load_topology(path: Path) -> Tuple[dict, Dict[str, dict], Dict[int, dict]]:
    topo = json.loads(path.read_text(encoding="utf-8"))
    link_by_name = {link["name"]: link for link in topo.get("links", [])}
    gpu_by_rank = {gpu["rank"]: gpu for gpu in topo.get("gpus", [])}
    return topo, link_by_name, gpu_by_rank


def pct_delta(value: float, baseline: float) -> float:
    if baseline == 0:
        return 0.0
    return (value - baseline) / baseline * 100.0


def summarize(events: Iterable[Event], link_by_name: Dict[str, dict], slow_factor: float) -> dict:
    events = list(events)
    global_median = median(e.duration_ms for e in events)

    by_rank: Dict[int, List[Event]] = defaultdict(list)
    by_link: Dict[str, List[Event]] = defaultdict(list)
    for e in events:
        by_rank[e.rank].append(e)
        by_link[e.link].append(e)

    rank_rows = []
    for rank, evs in sorted(by_rank.items()):
        med = median(e.duration_ms for e in evs)
        max_ms = max(e.duration_ms for e in evs)
        min_gbps = min(e.gbps for e in evs)
        slow_events = [e for e in evs if e.duration_ms >= global_median * slow_factor]
        rank_rows.append(
            {
                "rank": rank,
                "events": len(evs),
                "median_ms": med,
                "max_ms": max_ms,
                "min_gbps": min_gbps,
                "slow_events": len(slow_events),
                "score": pct_delta(med, global_median) + len(slow_events) * 50,
                "links": Counter(e.link for e in evs).most_common(),
            }
        )

    link_rows = []
    for name, evs in sorted(by_link.items()):
        med = median(e.duration_ms for e in evs)
        p95_proxy = max(e.duration_ms for e in evs)
        avg_gbps = sum(e.gbps for e in evs) / len(evs)
        topo = link_by_name.get(name, {})
        expected = topo.get("expected_gbps")
        ratio = (avg_gbps / expected) if expected else None
        slow_count = sum(1 for e in evs if e.duration_ms >= global_median * slow_factor)
        health = topo.get("health", "unknown")
        suspicious = slow_count > 0 or health == "suspect" or (ratio is not None and ratio < 0.55)
        link_rows.append(
            {
                "name": name,
                "type": topo.get("type", "unknown"),
                "pair": (topo.get("src"), topo.get("dst")),
                "health": health,
                "events": len(evs),
                "median_ms": med,
                "max_ms": p95_proxy,
                "avg_gbps": avg_gbps,
                "expected_gbps": expected,
                "throughput_ratio": ratio,
                "slow_events": slow_count,
                "suspicious": suspicious,
                "note": topo.get("note", ""),
            }
        )

    slow_ranks = sorted(rank_rows, key=lambda r: (r["score"], r["median_ms"]), reverse=True)
    suspicious_links = sorted([l for l in link_rows if l["suspicious"]], key=lambda l: (l["slow_events"], l["max_ms"]), reverse=True)
    return {
        "global_median_ms": global_median,
        "rank_rows": rank_rows,
        "link_rows": link_rows,
        "slow_ranks": slow_ranks,
        "suspicious_links": suspicious_links,
    }


def md_table(headers: List[str], rows: List[List[object]]) -> str:
    out = ["| " + " | ".join(headers) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"]
    for row in rows:
        out.append("| " + " | ".join(str(x) for x in row) + " |")
    return "\n".join(out)


def render_report(summary: dict, gpu_by_rank: Dict[int, dict]) -> str:
    slow_ranks = summary["slow_ranks"]
    suspicious_links = summary["suspicious_links"]
    top_rank = slow_ranks[0]

    rank_rows = []
    for r in slow_ranks:
        gpu = gpu_by_rank.get(r["rank"], {})
        rank_rows.append([
            r["rank"],
            gpu.get("gpu", "?"),
            gpu.get("numa", "?"),
            f'{r["median_ms"]:.1f}',
            f'{r["max_ms"]:.1f}',
            f'{r["min_gbps"]:.1f}',
            r["slow_events"],
            ", ".join(f"{k}x{v}" for k, v in r["links"]),
        ])

    link_rows = []
    for l in suspicious_links:
        pair = f'{l["pair"][0]}<->{l["pair"][1]}'
        ratio = "n/a" if l["throughput_ratio"] is None else f'{l["throughput_ratio"]:.2f}x'
        link_rows.append([
            l["name"], pair, l["type"], l["health"], f'{l["median_ms"]:.1f}', f'{l["max_ms"]:.1f}',
            f'{l["avg_gbps"]:.1f}', l["expected_gbps"], ratio, l["slow_events"], l["note"] or "-"
        ])

    commands = [
        "nvidia-smi topo -m",
        "nvidia-smi nvlink --status",
        "nvidia-smi dmon -s pucvmet -d 1",
        "dcgmi diag -r 3",
        "dcgmi dmon -e 1002,1003,1004,1005",
        "NCCL_DEBUG=INFO NCCL_DEBUG_SUBSYS=INIT,GRAPH,COLL ./your_nccl_test",
        "NCCL_TOPO_DUMP_FILE=/tmp/nccl_topo.xml NCCL_DEBUG=INFO ./your_nccl_test",
        "numactl --hardware && lspci -tv",
    ]

    return f"""# Slow Rank Report

## Verdict

Most likely slow rank: **rank {top_rank['rank']}**. It repeatedly touches the slow path and has max latency **{top_rank['max_ms']:.1f} ms** versus global median **{summary['global_median_ms']:.1f} ms**.

Primary suspect link: **{suspicious_links[0]['name'] if suspicious_links else 'none'}**. In this sample, the slow events cluster on the cross-socket / host-bridge path, so the first hypothesis is PCIe/NUMA topology or link health rather than a pure NCCL algorithm issue.

## Rank summary

{md_table(['Rank','GPU','NUMA','Median ms','Max ms','Min Gb/s','Slow events','Links seen'], rank_rows)}

## Suspicious links

{md_table(['Link','Pair','Type','Topo health','Median ms','Max ms','Avg Gb/s','Expected Gb/s','Ratio','Slow events','Note'], link_rows)}

## Next validation commands

```bash
{chr(10).join(commands)}
```

## Suggested triage order

1. Confirm whether NCCL chose a ring/tree edge across the same suspicious path.
2. Compare `nvidia-smi topo -m` with the JSON topology and check whether rank mapping is suboptimal.
3. Watch PCIe replay/error counters while re-running the collective benchmark.
4. Try a rank remap that avoids the suspicious edge, then compare p50/p95 latency.
5. If only this edge is slow under load, isolate hardware: cable/riser/switch/host bridge/NUMA placement.
"""


def main() -> int:
    parser = argparse.ArgumentParser(description="Find slow ranks from simplified NCCL trace and topology JSON")
    parser.add_argument("--trace", default="data/nccl_trace.log", type=Path)
    parser.add_argument("--topology", default="data/topology.json", type=Path)
    parser.add_argument("--out", default="reports/slow_rank_report.md", type=Path)
    parser.add_argument("--slow-factor", default=1.8, type=float, help="duration >= median*factor is marked slow")
    args = parser.parse_args()

    events = parse_trace(args.trace)
    _, link_by_name, gpu_by_rank = load_topology(args.topology)
    summary = summarize(events, link_by_name, args.slow_factor)
    report = render_report(summary, gpu_by_rank)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(report, encoding="utf-8")

    top = summary["slow_ranks"][0]
    print(f"slow_rank={top['rank']} max_ms={top['max_ms']:.1f} report={args.out}")
    if summary["suspicious_links"]:
        print("suspicious_links=" + ",".join(l["name"] for l in summary["suspicious_links"]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
