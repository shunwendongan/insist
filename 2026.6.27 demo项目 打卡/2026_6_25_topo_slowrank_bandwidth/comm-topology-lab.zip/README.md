# comm-topology-lab

一个最小可运行 demo：解析简化版 NCCL trace 和 GPU 拓扑 JSON，输出：

- 慢 rank
- 可疑链路
- 下一步验证命令

## 目录

```text
README.md
data/nccl_trace.log
data/topology.json
src/find_slow_rank.py
reports/slow_rank_report.md
```

## 快速运行

```bash
cd comm-topology-lab
python3 src/find_slow_rank.py
cat reports/slow_rank_report.md
```

也可以指定输入输出：

```bash
python3 src/find_slow_rank.py \
  --trace data/nccl_trace.log \
  --topology data/topology.json \
  --out reports/slow_rank_report.md \
  --slow-factor 1.8
```

## 样例输入格式

`data/nccl_trace.log` 是刻意简化过的 NCCL trace，每行一个通信事件：

```text
0.000 all_reduce ring rank=3 peer=4 bytes=268435456 duration_ms=38.7 link=PHB0
```

`data/topology.json` 描述 rank 到 GPU/NUMA 的映射，以及链路类型、理论带宽、健康状态。

## Demo 预期结论

样例数据里，`rank 3` 和 `rank 4` 附近的通信明显更慢，慢事件集中在 `PHB0` 这条跨 socket / host bridge 链路上。报告会建议先验证 PCIe/NUMA 拓扑、NCCL 选路、DCGM 计数器和 rank remap。
