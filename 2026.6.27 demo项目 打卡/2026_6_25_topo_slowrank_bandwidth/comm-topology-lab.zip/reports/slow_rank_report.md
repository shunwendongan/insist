# Slow Rank Report

## Verdict

Most likely slow rank: **rank 3**. It repeatedly touches the slow path and has max latency **41.5 ms** versus global median **13.1 ms**.

Primary suspect link: **PHB0**. In this sample, the slow events cluster on the cross-socket / host-bridge path, so the first hypothesis is PCIe/NUMA topology or link health rather than a pure NCCL algorithm issue.

## Rank summary

| Rank | GPU | NUMA | Median ms | Max ms | Min Gb/s | Slow events | Links seen |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 3 | GPU3 | 0 | 26.1 | 41.5 | 51.7 | 2 | PHB0x2, SYS1x1, PIX0x1 |
| 4 | GPU4 | 1 | 14.1 | 44.9 | 47.8 | 1 | PIX1x3, PHB0x1 |
| 5 | GPU5 | 1 | 13.8 | 14.1 | 124.9 | 0 | NVL2x3, PIX1x1 |
| 6 | GPU6 | 1 | 13.5 | 13.9 | 129.4 | 0 | NVL3x2, SYS2x1, NVL2x1 |
| 2 | GPU2 | 0 | 13.1 | 18.2 | 59.0 | 0 | PIX0x2, PHB0x1, NVL1x1 |
| 7 | GPU7 | 1 | 12.9 | 13.3 | 127.8 | 0 | PIX2x2, SYS3x1, NVL3x1 |
| 1 | GPU1 | 0 | 12.4 | 12.6 | 126.3 | 0 | NVL1x2, SYS0x1, NVL0x1 |
| 0 | GPU0 | 0 | 12.2 | 13.1 | 132.6 | 0 | NVL0x2, PIX0x1, PIX2x1 |

## Suspicious links

| Link | Pair | Type | Topo health | Median ms | Max ms | Avg Gb/s | Expected Gb/s | Ratio | Slow events | Note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| PHB0 | 3<->4 | PCIe host bridge | suspect | 40.1 | 44.9 | 53.5 | 32 | 1.67x | 3 | cross-socket path; prior DCGM saw replay counter bumps |
| NVL2 | 5<->6 | NVLink | ok | 13.8 | 13.9 | 147.9 | 300 | 0.49x | 0 | - |
| NVL3 | 6<->7 | NVLink | ok | 13.4 | 13.6 | 159.9 | 300 | 0.53x | 0 | - |

## Next validation commands

```bash
nvidia-smi topo -m
nvidia-smi nvlink --status
nvidia-smi dmon -s pucvmet -d 1
dcgmi diag -r 3
dcgmi dmon -e 1002,1003,1004,1005
NCCL_DEBUG=INFO NCCL_DEBUG_SUBSYS=INIT,GRAPH,COLL ./your_nccl_test
NCCL_TOPO_DUMP_FILE=/tmp/nccl_topo.xml NCCL_DEBUG=INFO ./your_nccl_test
numactl --hardware && lspci -tv
```

## Suggested triage order

1. Confirm whether NCCL chose a ring/tree edge across the same suspicious path.
2. Compare `nvidia-smi topo -m` with the JSON topology and check whether rank mapping is suboptimal.
3. Watch PCIe replay/error counters while re-running the collective benchmark.
4. Try a rank remap that avoids the suspicious edge, then compare p50/p95 latency.
5. If only this edge is slow under load, isolate hardware: cable/riser/switch/host bridge/NUMA placement.
